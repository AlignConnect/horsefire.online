import React from 'react'

const orderNow = () => {
    return (
        <div className="py-2 text-center text-2xl text-blue-600 font-extrabold pop_imagehfv ">
            <a href='#form' className='  fontNoto '>
                ऑर्डर करने के लिए यहां क्लिक करें
            </a>
        </div>
    )
}

export default orderNow